angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('chatChoices', {
    url: '/page3',
    templateUrl: 'templates/chatChoices.html',
    controller: 'chatChoicesCtrl'
  })

  .state('login', {
    url: '/page4',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('locationChoice', {
    url: '/page8',
    templateUrl: 'templates/locationChoice.html',
    controller: 'locationChoiceCtrl'
  })

  .state('chatItUp', {
    url: '/page9',
    templateUrl: 'templates/chatItUp.html',
    controller: 'chatItUpCtrl'
  })

$urlRouterProvider.otherwise('/page4')

  

});